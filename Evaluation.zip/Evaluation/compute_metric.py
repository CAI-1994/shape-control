#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Batch-compute 2D shape metrics for every method/camera pair in ``data/``.

The script pairs prediction and ground-truth images by identical camera folder
and identical PNG filename. It creates:

* ``metrics_results.xlsx``: method-level sheets with camera and overall
  mean/population-standard-deviation summaries.
* ``metrics_case-level.xlsx``: method-level sheets with one row per image pair.

Calculated metrics:

* Dice;
* 95th-percentile Hausdorff distance (HD95);
* centerline-position RMSE;
* absolute-curvature RMSE;
* average symmetric surface distance (ASSD).
"""

from __future__ import annotations

import argparse
import math
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

import numpy as np
from openpyxl import Workbook, load_workbook

from metric.assd import ASSD
from metric.centrerline import CenterlineRMSE
from metric.curvature import Curvature
from metric.dice import Dice
from metric.hd95 import HD95
from metric.preprocess import (
    MaskData,
    PreprocessError,
    load_binary_mask,
    validate_mask_pair,
)


PROJECT_ROOT = Path(__file__).resolve().parent
DEFAULT_DATA_ROOT = PROJECT_ROOT / "data"
DEFAULT_GT_DIR = "test3-ground truth"
DEFAULT_RESULTS_PATH = PROJECT_ROOT / "metrics_results.xlsx"
DEFAULT_CASE_LEVEL_PATH = PROJECT_ROOT / "metrics_case-level.xlsx"


@dataclass(frozen=True)
class CaseMetric:
    method: str
    method_directory: str
    camera: str
    case_id: int | str
    filename: str
    ground_truth_path: str
    prediction_path: str
    ground_truth_pixels: int
    prediction_pixels: int
    dice: float
    hd95: float | None
    centerline_rmse: float | None
    curvature_rmse: float | None
    assd: float | None
    status: str


@dataclass(frozen=True)
class SummaryMetric:
    scope: str
    valid_dice_count: int
    dice_mean: float | None
    dice_std: float | None
    valid_hd95_count: int
    hd95_mean: float | None
    hd95_std: float | None
    valid_centerline_rmse_count: int
    centerline_rmse_mean: float | None
    centerline_rmse_std: float | None
    valid_curvature_rmse_count: int
    curvature_rmse_mean: float | None
    curvature_rmse_std: float | None
    valid_assd_count: int
    assd_mean: float | None
    assd_std: float | None


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Compute Dice, HD95, centerline RMSE, curvature RMSE, and ASSD "
            "for method outputs versus ground truth."
        )
    )
    parser.add_argument(
        "--data-root",
        type=Path,
        default=DEFAULT_DATA_ROOT,
        help=f"Dataset root (default: {DEFAULT_DATA_ROOT})",
    )
    parser.add_argument(
        "--gt-dir",
        default=DEFAULT_GT_DIR,
        help=f"Ground-truth directory name (default: {DEFAULT_GT_DIR!r})",
    )
    parser.add_argument(
        "--methods",
        nargs="*",
        default=None,
        help=(
            "Optional method directory names or labels. "
            "By default, all compatible method directories are used."
        ),
    )
    parser.add_argument(
        "--cameras",
        nargs="*",
        default=None,
        help="Optional camera folder names. By default, all GT cameras are used.",
    )
    parser.add_argument(
        "--background-tolerance",
        type=int,
        default=0,
        help=(
            "Maximum RGB distance from white still treated as background "
            "(default: 0)."
        ),
    )
    parser.add_argument(
        "--spacing",
        type=float,
        nargs=2,
        metavar=("ROW_SPACING", "COL_SPACING"),
        default=(1.0, 1.0),
        help=(
            "Row/column pixel or physical spacing for all distance and "
            "curvature metrics (default: 1.0 1.0)."
        ),
    )
    parser.add_argument(
        "--n-points",
        type=int,
        default=200,
        help="Arc-length samples on each extracted centerline (default: 200).",
    )
    parser.add_argument(
        "--smooth-window",
        type=int,
        default=21,
        help=(
            "Savitzky-Golay smoothing window used by curvature RMSE "
            "(default: 21; adjusted to a valid odd size when needed)."
        ),
    )
    parser.add_argument(
        "--polyorder",
        type=int,
        default=3,
        help="Savitzky-Golay polynomial order (default: 3).",
    )
    parser.add_argument(
        "--results-xlsx",
        type=Path,
        default=DEFAULT_RESULTS_PATH,
        help=f"Summary workbook path (default: {DEFAULT_RESULTS_PATH})",
    )
    parser.add_argument(
        "--case-level-xlsx",
        type=Path,
        default=DEFAULT_CASE_LEVEL_PATH,
        help=f"Case-level workbook path (default: {DEFAULT_CASE_LEVEL_PATH})",
    )
    return parser.parse_args()


def natural_image_key(path: Path) -> tuple[int, int | str]:
    if path.stem.isdigit():
        return (0, int(path.stem))
    return (1, path.stem)


def display_method_name(directory_name: str) -> str:
    for prefix in ("test3_4001-5000_", "test3_"):
        if directory_name.startswith(prefix):
            return directory_name[len(prefix) :]
    return directory_name


def safe_sheet_name(value: str) -> str:
    cleaned = re.sub(r"[\[\]:*?/\\]", "_", value)
    return cleaned[:31] or "Sheet"


def camera_directories(dataset_dir: Path) -> list[Path]:
    return sorted(
        (
            path
            for path in dataset_dir.iterdir()
            if path.is_dir() and any(path.glob("*.png"))
        ),
        key=lambda path: path.name,
    )


def discover_datasets(
    data_root: Path,
    gt_dir_name: str,
    selected_methods: Sequence[str] | None,
    selected_cameras: Sequence[str] | None,
) -> tuple[Path, list[Path], list[str]]:
    data_root = data_root.resolve()
    gt_dir = data_root / gt_dir_name
    if not gt_dir.is_dir():
        raise FileNotFoundError(f"Ground-truth directory not found: {gt_dir}")

    available_camera_names = [path.name for path in camera_directories(gt_dir)]
    if not available_camera_names:
        raise FileNotFoundError(f"No PNG camera directories found under {gt_dir}")

    if selected_cameras:
        unknown_cameras = sorted(set(selected_cameras) - set(available_camera_names))
        if unknown_cameras:
            raise ValueError(
                f"Requested cameras are absent from GT: {', '.join(unknown_cameras)}"
            )
        camera_names = list(selected_cameras)
    else:
        camera_names = available_camera_names

    method_dirs = []
    for path in sorted(data_root.iterdir(), key=lambda item: item.name):
        if not path.is_dir() or path.name == gt_dir_name:
            continue
        if all((path / camera_name).is_dir() for camera_name in camera_names):
            method_dirs.append(path)

    if selected_methods:
        requested = set(selected_methods)
        filtered = [
            path
            for path in method_dirs
            if path.name in requested or display_method_name(path.name) in requested
        ]
        resolved = {
            name
            for path in filtered
            for name in (path.name, display_method_name(path.name))
        }
        unknown_methods = sorted(requested - resolved)
        if unknown_methods:
            raise ValueError(
                "Requested methods were not found or are missing camera folders: "
                + ", ".join(unknown_methods)
            )
        method_dirs = filtered

    if not method_dirs:
        raise FileNotFoundError(
            f"No compatible method directories found under {data_root}"
        )

    return gt_dir, method_dirs, camera_names


def pair_camera_images(
    gt_camera_dir: Path,
    prediction_camera_dir: Path,
) -> list[tuple[Path, Path]]:
    gt_files = {path.name: path for path in gt_camera_dir.glob("*.png")}
    prediction_files = {
        path.name: path for path in prediction_camera_dir.glob("*.png")
    }
    missing_predictions = sorted(
        set(gt_files) - set(prediction_files),
        key=lambda name: natural_image_key(Path(name)),
    )
    extra_predictions = sorted(
        set(prediction_files) - set(gt_files),
        key=lambda name: natural_image_key(Path(name)),
    )
    if missing_predictions or extra_predictions:
        raise ValueError(
            f"Image pairing mismatch for {prediction_camera_dir} versus "
            f"{gt_camera_dir}. Missing predictions: "
            f"{missing_predictions[:10]}; extra predictions: "
            f"{extra_predictions[:10]}"
        )
    if not gt_files:
        raise FileNotFoundError(f"No PNG files found in {gt_camera_dir}")

    ordered_names = sorted(gt_files, key=lambda name: natural_image_key(Path(name)))
    return [(gt_files[name], prediction_files[name]) for name in ordered_names]


def relative_display_path(path: Path) -> str:
    try:
        return str(path.resolve().relative_to(PROJECT_ROOT.resolve()))
    except ValueError:
        return str(path.resolve())


def empty_status(gt: MaskData, prediction: MaskData) -> str:
    if gt.is_empty and prediction.is_empty:
        return "empty_gt_and_prediction"
    if gt.is_empty:
        return "empty_gt"
    if prediction.is_empty:
        return "empty_prediction"
    return "ok"


def calculate_case(
    method: str,
    method_directory: str,
    camera: str,
    gt_path: Path,
    prediction_path: Path,
    *,
    background_tolerance: int,
    spacing: tuple[float, float],
    n_points: int,
    smooth_window: int,
    polyorder: int,
) -> CaseMetric:
    try:
        gt = load_binary_mask(
            gt_path,
            background_tolerance=background_tolerance,
        )
        prediction = load_binary_mask(
            prediction_path,
            expected_shape=gt.image_shape,
            background_tolerance=background_tolerance,
        )
        validate_mask_pair(gt, prediction)
    except PreprocessError as error:
        raise PreprocessError(
            f"Failed to preprocess pair {gt_path.name} in camera {camera}: {error}"
        ) from error

    status = empty_status(gt, prediction)
    dice_value = float(Dice(gt.mask, prediction.mask))
    hd95_value = float(HD95(gt.mask, prediction.mask, spacing))
    centerline_rmse_value = float(
        CenterlineRMSE(
            gt.mask,
            prediction.mask,
            spacing_mm=spacing,
            n_points=n_points,
        )
    )
    curvature_rmse_value = float(
        Curvature(
            gt.mask,
            prediction.mask,
            spacing_mm=spacing,
            n_points=n_points,
            smooth_window=smooth_window,
            polyorder=polyorder,
        )
    )
    assd_value = float(ASSD(gt.mask, prediction.mask, spacing_mm=spacing))

    def finite_or_none(value: float) -> float | None:
        return value if math.isfinite(value) else None

    case_id: int | str = (
        int(gt_path.stem) if gt_path.stem.isdigit() else gt_path.stem
    )

    return CaseMetric(
        method=method,
        method_directory=method_directory,
        camera=camera,
        case_id=case_id,
        filename=gt_path.name,
        ground_truth_path=relative_display_path(gt_path),
        prediction_path=relative_display_path(prediction_path),
        ground_truth_pixels=gt.foreground_pixels,
        prediction_pixels=prediction.foreground_pixels,
        dice=dice_value,
        hd95=finite_or_none(hd95_value),
        centerline_rmse=finite_or_none(centerline_rmse_value),
        curvature_rmse=finite_or_none(curvature_rmse_value),
        assd=finite_or_none(assd_value),
        status=status,
    )


def finite_statistics(values: Iterable[float | None]) -> tuple[int, float | None, float | None]:
    finite_values = np.asarray(
        [
            float(value)
            for value in values
            if value is not None and math.isfinite(float(value))
        ],
        dtype=float,
    )
    if finite_values.size == 0:
        return 0, None, None
    return (
        int(finite_values.size),
        float(np.mean(finite_values)),
        float(np.std(finite_values, ddof=0)),
    )


def format_metric(value: float | None) -> str:
    """Format an optional metric value for progress logging."""
    if value is None or not math.isfinite(float(value)):
        return "N/A"
    return f"{float(value):.6f}"


def summarize_cases(scope: str, cases: Sequence[CaseMetric]) -> SummaryMetric:
    valid_dice_count, dice_mean, dice_std = finite_statistics(
        case.dice for case in cases
    )
    valid_hd95_count, hd95_mean, hd95_std = finite_statistics(
        case.hd95 for case in cases
    )
    (
        valid_centerline_rmse_count,
        centerline_rmse_mean,
        centerline_rmse_std,
    ) = finite_statistics(case.centerline_rmse for case in cases)
    (
        valid_curvature_rmse_count,
        curvature_rmse_mean,
        curvature_rmse_std,
    ) = finite_statistics(case.curvature_rmse for case in cases)
    valid_assd_count, assd_mean, assd_std = finite_statistics(
        case.assd for case in cases
    )
    return SummaryMetric(
        scope=scope,
        valid_dice_count=valid_dice_count,
        dice_mean=dice_mean,
        dice_std=dice_std,
        valid_hd95_count=valid_hd95_count,
        hd95_mean=hd95_mean,
        hd95_std=hd95_std,
        valid_centerline_rmse_count=valid_centerline_rmse_count,
        centerline_rmse_mean=centerline_rmse_mean,
        centerline_rmse_std=centerline_rmse_std,
        valid_curvature_rmse_count=valid_curvature_rmse_count,
        curvature_rmse_mean=curvature_rmse_mean,
        curvature_rmse_std=curvature_rmse_std,
        valid_assd_count=valid_assd_count,
        assd_mean=assd_mean,
        assd_std=assd_std,
    )


def compute_all_metrics(
    gt_dir: Path,
    method_dirs: Sequence[Path],
    camera_names: Sequence[str],
    *,
    background_tolerance: int,
    spacing: tuple[float, float],
    n_points: int,
    smooth_window: int,
    polyorder: int,
) -> tuple[dict[str, list[CaseMetric]], dict[str, list[SummaryMetric]]]:
    cases_by_method: dict[str, list[CaseMetric]] = {}
    summaries_by_method: dict[str, list[SummaryMetric]] = {}

    for method_dir in method_dirs:
        method = display_method_name(method_dir.name)
        method_cases: list[CaseMetric] = []
        method_summaries: list[SummaryMetric] = []
        print(f"[method] {method_dir.name} versus {gt_dir.name}", flush=True)

        for camera in camera_names:
            pairs = pair_camera_images(gt_dir / camera, method_dir / camera)
            camera_cases = [
                calculate_case(
                    method,
                    method_dir.name,
                    camera,
                    gt_path,
                    prediction_path,
                    background_tolerance=background_tolerance,
                    spacing=spacing,
                    n_points=n_points,
                    smooth_window=smooth_window,
                    polyorder=polyorder,
                )
                for gt_path, prediction_path in pairs
            ]
            camera_summary = summarize_cases(camera, camera_cases)
            method_cases.extend(camera_cases)
            method_summaries.append(camera_summary)
            print(
                f"  [camera] {camera}: n={len(camera_cases)}, "
                f"Dice={format_metric(camera_summary.dice_mean)}, "
                f"HD95={format_metric(camera_summary.hd95_mean)}, "
                "CenterlineRMSE="
                f"{format_metric(camera_summary.centerline_rmse_mean)}, "
                "CurvatureRMSE="
                f"{format_metric(camera_summary.curvature_rmse_mean)}, "
                f"ASSD={format_metric(camera_summary.assd_mean)}",
                flush=True,
            )

        method_summaries.append(summarize_cases("Overall", method_cases))
        cases_by_method[method] = method_cases
        summaries_by_method[method] = method_summaries

    return cases_by_method, summaries_by_method


def remove_default_sheet(workbook: Workbook) -> None:
    default_sheet = workbook.active
    workbook.remove(default_sheet)


def add_case_level_sheet(
    workbook: Workbook,
    method: str,
    cases: Sequence[CaseMetric],
) -> None:
    sheet_name = safe_sheet_name(f"{method}_vs_GT")
    worksheet = workbook.create_sheet(sheet_name)
    worksheet.append(
        [
            "Camera",
            "Case ID",
            "Dice",
            "HD95",
            "Centerline RMSE",
            "Curvature RMSE",
            "ASSD",
        ]
    )

    for case in cases:
        worksheet.append(
            [
                case.camera,
                case.case_id,
                case.dice,
                case.hd95,
                case.centerline_rmse,
                case.curvature_rmse,
                case.assd,
            ]
        )
    worksheet.column_dimensions["A"].width = 30
    worksheet.column_dimensions["B"].width = 12
    for column in ("C", "D", "E", "F", "G"):
        worksheet.column_dimensions[column].width = 20


def add_summary_sheet(
    workbook: Workbook,
    method: str,
    summaries: Sequence[SummaryMetric],
) -> None:
    sheet_name = safe_sheet_name(f"{method}_vs_GT")
    worksheet = workbook.create_sheet(sheet_name)
    worksheet.append(
        [
            "Camera / Scope",
            "Valid Dice",
            "Dice Mean",
            "Dice Std",
            "Valid HD95",
            "HD95 Mean (spacing unit)",
            "HD95 Std (spacing unit)",
            "Valid Centerline RMSE",
            "Centerline RMSE Mean (spacing unit)",
            "Centerline RMSE Std (spacing unit)",
            "Valid Curvature RMSE",
            "Curvature RMSE Mean (1/spacing unit)",
            "Curvature RMSE Std (1/spacing unit)",
            "Valid ASSD",
            "ASSD Mean (spacing unit)",
            "ASSD Std (spacing unit)",
        ]
    )

    for summary in summaries:
        worksheet.append(
            [
                summary.scope,
                summary.valid_dice_count,
                summary.dice_mean,
                summary.dice_std,
                summary.valid_hd95_count,
                summary.hd95_mean,
                summary.hd95_std,
                summary.valid_centerline_rmse_count,
                summary.centerline_rmse_mean,
                summary.centerline_rmse_std,
                summary.valid_curvature_rmse_count,
                summary.curvature_rmse_mean,
                summary.curvature_rmse_std,
                summary.valid_assd_count,
                summary.assd_mean,
                summary.assd_std,
            ]
        )
    worksheet.column_dimensions["A"].width = 30
    worksheet.column_dimensions["B"].width = 12
    for column in ("C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P"):
        worksheet.column_dimensions[column].width = 23
    worksheet.print_area = f"A1:P{len(summaries) + 1}"
    worksheet.page_setup.orientation = "landscape"
    worksheet.page_setup.fitToWidth = 1
    worksheet.page_setup.fitToHeight = 1
    worksheet.sheet_properties.pageSetUpPr.fitToPage = True


def write_case_level_workbook(
    output_path: Path,
    cases_by_method: dict[str, list[CaseMetric]],
) -> None:
    workbook = Workbook()
    remove_default_sheet(workbook)
    workbook.properties.title = "Case-level 2D shape metric results"
    workbook.properties.creator = "compute_metric.py"

    for method, cases in cases_by_method.items():
        add_case_level_sheet(workbook, method, cases)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(output_path)


def write_summary_workbook(
    output_path: Path,
    summaries_by_method: dict[str, list[SummaryMetric]],
) -> None:
    workbook = Workbook()
    remove_default_sheet(workbook)
    workbook.properties.title = "2D shape metric summary results"
    workbook.properties.creator = "compute_metric.py"

    for method, summaries in summaries_by_method.items():
        add_summary_sheet(workbook, method, summaries)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(output_path)


def validate_workbook(
    workbook_path: Path,
    *,
    expected_sheets: Sequence[str],
    minimum_rows: int,
) -> None:
    if not workbook_path.is_file() or workbook_path.stat().st_size == 0:
        raise RuntimeError(f"Workbook was not created correctly: {workbook_path}")

    workbook = load_workbook(workbook_path, read_only=False, data_only=False)
    actual_sheets = workbook.sheetnames
    if actual_sheets != list(expected_sheets):
        raise RuntimeError(
            f"Unexpected sheets in {workbook_path}: {actual_sheets}; "
            f"expected {list(expected_sheets)}"
        )
    for worksheet in workbook.worksheets:
        if worksheet.max_row < minimum_rows:
            raise RuntimeError(
                f"Worksheet {worksheet.title} in {workbook_path} has only "
                f"{worksheet.max_row} rows"
            )
        if worksheet["A1"].value is None:
            raise RuntimeError(
                f"Worksheet {worksheet.title} in {workbook_path} has no header"
            )
    workbook.close()


def main() -> None:
    args = parse_args()
    if any(value <= 0 for value in args.spacing):
        raise ValueError("--spacing values must be positive")
    if not 0 <= args.background_tolerance <= 255:
        raise ValueError("--background-tolerance must be between 0 and 255")
    if args.n_points < 7:
        raise ValueError("--n-points must be at least 7 for curvature estimation")
    if args.smooth_window < 1:
        raise ValueError("--smooth-window must be positive")
    if args.polyorder < 1:
        raise ValueError("--polyorder must be at least 1")
    max_odd_points = args.n_points if args.n_points % 2 == 1 else args.n_points - 1
    minimum_window = args.polyorder + 2
    if minimum_window % 2 == 0:
        minimum_window += 1
    if minimum_window > max_odd_points:
        raise ValueError("--polyorder is too large for --n-points")

    gt_dir, method_dirs, camera_names = discover_datasets(
        args.data_root,
        args.gt_dir,
        args.methods,
        args.cameras,
    )
    spacing = (float(args.spacing[0]), float(args.spacing[1]))
    print(f"[data] GT: {gt_dir}", flush=True)
    print(
        "[data] methods: " + ", ".join(path.name for path in method_dirs),
        flush=True,
    )
    print("[data] cameras: " + ", ".join(camera_names), flush=True)
    print(
        "[preprocess] foreground = RGB difference from white > "
        f"{args.background_tolerance}; no geometry modification",
        flush=True,
    )
    print(
        "[centerline] largest component -> fill holes -> skeletonize -> "
        f"longest path -> {args.n_points} arc-length samples; "
        f"curvature smoothing={args.smooth_window}, polyorder={args.polyorder}",
        flush=True,
    )

    cases_by_method, summaries_by_method = compute_all_metrics(
        gt_dir,
        method_dirs,
        camera_names,
        background_tolerance=args.background_tolerance,
        spacing=spacing,
        n_points=args.n_points,
        smooth_window=args.smooth_window,
        polyorder=args.polyorder,
    )

    write_case_level_workbook(
        args.case_level_xlsx,
        cases_by_method,
    )
    write_summary_workbook(
        args.results_xlsx,
        summaries_by_method,
    )

    expected_sheets = [
        safe_sheet_name(f"{method}_vs_GT") for method in cases_by_method
    ]
    validate_workbook(
        args.case_level_xlsx,
        expected_sheets=expected_sheets,
        minimum_rows=5,
    )
    validate_workbook(
        args.results_xlsx,
        expected_sheets=expected_sheets,
        minimum_rows=4,
    )
    print(f"[output] {args.results_xlsx.resolve()}", flush=True)
    print(f"[output] {args.case_level_xlsx.resolve()}", flush=True)


if __name__ == "__main__":
    main()
