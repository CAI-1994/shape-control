# -*- coding: utf-8 -*-
"""95th-percentile Hausdorff distance (HD95) calculation.

The implementation is based on the surface-distance code used by
``ViTRegist/utils/metrics.py``. The 2D lookup table is included locally so the
module can run in the current project without importing ``ViTRegist/utils``.

The current PNG data is 2D, so :func:`HD95` accepts a single 2D mask. The
``compute_surface_distances`` and ``compute_robust_hausdorff`` helpers are also
exposed for direct use.
"""

import math

import numpy as np
from scipy import ndimage

try:
    import torch
except ImportError:  # pragma: no cover - NumPy inputs do not need PyTorch
    torch = None


ENCODE_NEIGHBOURHOOD_2D_KERNEL = np.array([[8, 4], [2, 1]])


def _contour_length_table(spacing_mm):
    """Create the 2D contour-length lookup table used by the source code."""
    spacing_mm = np.asarray(spacing_mm, dtype=float)
    vertical, horizontal = spacing_mm
    diag = 0.5 * math.sqrt(vertical**2 + horizontal**2)
    table = np.zeros(16, dtype=float)

    table[int("0001", 2)] = diag
    table[int("0010", 2)] = diag
    table[int("0011", 2)] = horizontal
    table[int("0100", 2)] = diag
    table[int("0101", 2)] = vertical
    table[int("0110", 2)] = 2 * diag
    table[int("0111", 2)] = diag
    table[int("1000", 2)] = diag
    table[int("1001", 2)] = 2 * diag
    table[int("1010", 2)] = vertical
    table[int("1011", 2)] = diag
    table[int("1100", 2)] = horizontal
    table[int("1101", 2)] = diag
    table[int("1110", 2)] = diag
    return table


def _compute_bounding_box(mask):
    num_dims = len(mask.shape)
    bbox_min = np.zeros(num_dims, np.int64)
    bbox_max = np.zeros(num_dims, np.int64)

    projection = np.amax(mask, axis=tuple(range(num_dims))[1:])
    nonzero = np.nonzero(projection)[0]
    if len(nonzero) == 0:
        return None, None

    bbox_min[0] = np.min(nonzero)
    bbox_max[0] = np.max(nonzero)

    for axis in range(1, num_dims):
        axes = list(range(num_dims))
        axes.pop(axis)
        projection = np.amax(mask, axis=tuple(axes))
        nonzero = np.nonzero(projection)[0]
        bbox_min[axis] = np.min(nonzero)
        bbox_max[axis] = np.max(nonzero)

    return bbox_min, bbox_max


def _crop_to_bounding_box(mask, bbox_min, bbox_max):
    cropmask = np.zeros((bbox_max - bbox_min) + 2, np.uint8)
    cropmask[0:-1, 0:-1] = mask[
        bbox_min[0] : bbox_max[0] + 1,
        bbox_min[1] : bbox_max[1] + 1,
    ]
    return cropmask


def _sort_distances_surfels(distances, surfel_areas):
    sorted_surfels = np.array(sorted(zip(distances, surfel_areas)))
    return sorted_surfels[:, 0], sorted_surfels[:, 1]


def compute_surface_distances(mask_gt, mask_pred, spacing_mm=(1.0, 1.0)):
    """Compute 2D surface distances in the same format as the source code."""
    mask_gt = np.asarray(mask_gt, dtype=bool)
    mask_pred = np.asarray(mask_pred, dtype=bool)
    spacing_mm = np.asarray(spacing_mm, dtype=float)

    if mask_gt.ndim != 2 or mask_pred.ndim != 2:
        raise ValueError("Only 2D masks are supported by this copied HD95 module.")
    if mask_gt.shape != mask_pred.shape or spacing_mm.shape != (2,):
        raise ValueError(
            "mask_gt, mask_pred, and spacing_mm must have compatible shapes: "
            f"got {mask_gt.shape}, {mask_pred.shape}, and {spacing_mm.shape}"
        )
    if np.any(spacing_mm <= 0):
        raise ValueError("spacing_mm values must be positive")

    bbox_min, bbox_max = _compute_bounding_box(mask_gt | mask_pred)
    if bbox_min is None:
        empty = np.array([], dtype=float)
        return {
            "distances_gt_to_pred": empty,
            "distances_pred_to_gt": empty,
            "surfel_areas_gt": empty,
            "surfel_areas_pred": empty,
        }

    cropmask_gt = _crop_to_bounding_box(mask_gt, bbox_min, bbox_max)
    cropmask_pred = _crop_to_bounding_box(mask_pred, bbox_min, bbox_max)

    kernel = ENCODE_NEIGHBOURHOOD_2D_KERNEL
    neighbour_code_map_gt = ndimage.correlate(
        cropmask_gt, kernel, mode="constant", cval=0
    )
    neighbour_code_map_pred = ndimage.correlate(
        cropmask_pred, kernel, mode="constant", cval=0
    )

    borders_gt = (neighbour_code_map_gt != 0) & (neighbour_code_map_gt != 15)
    borders_pred = (neighbour_code_map_pred != 0) & (neighbour_code_map_pred != 15)

    if borders_gt.any():
        distmap_gt = ndimage.distance_transform_edt(
            ~borders_gt, sampling=spacing_mm
        )
    else:
        distmap_gt = np.full(borders_gt.shape, np.inf)

    if borders_pred.any():
        distmap_pred = ndimage.distance_transform_edt(
            ~borders_pred, sampling=spacing_mm
        )
    else:
        distmap_pred = np.full(borders_pred.shape, np.inf)

    contour_lengths = _contour_length_table(spacing_mm)
    surface_length_map_gt = contour_lengths[neighbour_code_map_gt]
    surface_length_map_pred = contour_lengths[neighbour_code_map_pred]

    distances_gt_to_pred = distmap_pred[borders_gt]
    distances_pred_to_gt = distmap_gt[borders_pred]
    surfel_areas_gt = surface_length_map_gt[borders_gt]
    surfel_areas_pred = surface_length_map_pred[borders_pred]

    if distances_gt_to_pred.shape != (0,):
        distances_gt_to_pred, surfel_areas_gt = _sort_distances_surfels(
            distances_gt_to_pred, surfel_areas_gt
        )
    if distances_pred_to_gt.shape != (0,):
        distances_pred_to_gt, surfel_areas_pred = _sort_distances_surfels(
            distances_pred_to_gt, surfel_areas_pred
        )

    return {
        "distances_gt_to_pred": distances_gt_to_pred,
        "distances_pred_to_gt": distances_pred_to_gt,
        "surfel_areas_gt": surfel_areas_gt,
        "surfel_areas_pred": surfel_areas_pred,
    }


def compute_robust_hausdorff(surface_distances, percent=95.0):
    """Compute the area-weighted percentile Hausdorff distance."""
    distances_gt_to_pred = surface_distances["distances_gt_to_pred"]
    distances_pred_to_gt = surface_distances["distances_pred_to_gt"]
    surfel_areas_gt = surface_distances["surfel_areas_gt"]
    surfel_areas_pred = surface_distances["surfel_areas_pred"]

    if len(distances_gt_to_pred) > 0:
        cumulative = np.cumsum(surfel_areas_gt) / np.sum(surfel_areas_gt)
        index = np.searchsorted(cumulative, percent / 100.0)
        gt_to_pred = distances_gt_to_pred[min(index, len(distances_gt_to_pred) - 1)]
    else:
        gt_to_pred = np.inf

    if len(distances_pred_to_gt) > 0:
        cumulative = np.cumsum(surfel_areas_pred) / np.sum(surfel_areas_pred)
        index = np.searchsorted(cumulative, percent / 100.0)
        pred_to_gt = distances_pred_to_gt[min(index, len(distances_pred_to_gt) - 1)]
    else:
        pred_to_gt = np.inf

    return float(max(gt_to_pred, pred_to_gt))


def _to_numpy_bool(mask):
    if torch is not None and torch.is_tensor(mask):
        return mask.detach().cpu().numpy().astype(bool, copy=False)
    return np.asarray(mask).astype(bool, copy=False)


def HD95(fix, move, spacing_mm=(1.0, 1.0)):
    """Calculate HD95 for two 2D masks.

    An empty mask on either side returns ``inf``, matching the source
    implementation's behavior.
    """
    fix = _to_numpy_bool(fix)
    move = _to_numpy_bool(move)
    if fix.shape != move.shape:
        raise ValueError(
            f"Received two masks with different shapes: fix -> {fix.shape}, "
            f"move -> {move.shape}"
        )
    if fix.ndim != 2:
        raise ValueError(
            f"Unsupported evaluation dimension {fix.ndim}; "
            "pass one 2D mask at a time"
        )

    distances = compute_surface_distances(fix, move, spacing_mm)
    return compute_robust_hausdorff(distances, 95.0)


def hd95(fix, move, spacing_mm=(1.0, 1.0)):
    """Lower-case alias for :func:`HD95`."""
    return HD95(fix, move, spacing_mm)


__all__ = [
    "HD95",
    "hd95",
    "compute_surface_distances",
    "compute_robust_hausdorff",
]
