# -*- coding: utf-8 -*-
"""Absolute-curvature RMSE for centerlines extracted from 2D binary masks.

Both masks follow the same preprocessing and arc-length correspondence used by
``metric.centrerline.CenterlineRMSE``. Coordinates are smoothed with a
Savitzky-Golay filter before first and second derivatives are calculated.
Endpoint samples are trimmed because rasterized skeleton curvature is least
stable there.
"""

from __future__ import annotations

from typing import Sequence

import numpy as np
from scipy.signal import savgol_filter

from metric.centrerline import (
    CenterlineError,
    align_curve_direction,
    as_2d_binary_mask,
    extract_resampled_centerline,
    validate_spacing,
)


def _effective_smoothing_window(
    n_points: int,
    smooth_window: int,
    polyorder: int,
) -> int:
    if n_points < 7:
        raise ValueError("At least seven centerline points are required")
    if polyorder < 1:
        raise ValueError("polyorder must be at least 1")
    if smooth_window < 1:
        raise ValueError("smooth_window must be positive")

    max_odd_window = n_points if n_points % 2 == 1 else n_points - 1
    minimum_window = polyorder + 2
    if minimum_window % 2 == 0:
        minimum_window += 1
    if minimum_window > max_odd_window:
        raise ValueError(
            f"polyorder {polyorder} is too large for {n_points} curve points"
        )

    window = min(int(smooth_window), max_odd_window)
    if window % 2 == 0:
        window -= 1
    return max(window, minimum_window)


def calculate_curvature(
    curve,
    smooth_window: int = 21,
    polyorder: int = 3,
    *,
    signed: bool = False,
) -> np.ndarray:
    """Calculate 2D curvature along an ordered ``N x 2`` curve.

    The output unit is the inverse of the curve-coordinate unit.
    """
    points = np.asarray(curve, dtype=float)
    if points.ndim != 2 or points.shape[1] != 2:
        raise ValueError(f"curve must have shape N x 2, received {points.shape}")

    window = _effective_smoothing_window(
        len(points),
        int(smooth_window),
        int(polyorder),
    )
    x = savgol_filter(
        points[:, 0],
        window_length=window,
        polyorder=int(polyorder),
        mode="interp",
    )
    y = savgol_filter(
        points[:, 1],
        window_length=window,
        polyorder=int(polyorder),
        mode="interp",
    )

    parameter = np.linspace(0.0, 1.0, len(points))
    dx = np.gradient(x, parameter)
    dy = np.gradient(y, parameter)
    ddx = np.gradient(dx, parameter)
    ddy = np.gradient(dy, parameter)

    numerator = dx * ddy - dy * ddx
    denominator = np.maximum((dx * dx + dy * dy) ** 1.5, 1e-12)
    curvature_values = numerator / denominator
    return curvature_values if signed else np.abs(curvature_values)


def Curvature(
    fix,
    move,
    spacing_mm: Sequence[float] = (1.0, 1.0),
    n_points: int = 200,
    smooth_window: int = 21,
    polyorder: int = 3,
    *,
    signed: bool = False,
) -> float:
    """Calculate centerline curvature RMSE for two 2D masks.

    ``fix`` is the reference mask and ``move`` is the prediction. The default
    compares absolute curvature, making the result independent of arbitrary
    path orientation. If either mask has no valid centerline, ``inf`` is
    returned.
    """
    fix_mask = as_2d_binary_mask(fix)
    move_mask = as_2d_binary_mask(move)
    if fix_mask.shape != move_mask.shape:
        raise ValueError(
            f"Received two masks with different shapes: fix -> {fix_mask.shape}, "
            f"move -> {move_mask.shape}"
        )
    validate_spacing(spacing_mm)
    effective_window = _effective_smoothing_window(
        int(n_points),
        int(smooth_window),
        int(polyorder),
    )

    if not fix_mask.any() or not move_mask.any():
        return float("inf")

    try:
        reference_curve = extract_resampled_centerline(
            fix_mask,
            spacing_mm=spacing_mm,
            n_points=n_points,
        )
        candidate_curve = extract_resampled_centerline(
            move_mask,
            spacing_mm=spacing_mm,
            n_points=n_points,
        )
    except CenterlineError:
        return float("inf")

    candidate_curve, _ = align_curve_direction(reference_curve, candidate_curve)
    reference_curvature = calculate_curvature(
        reference_curve,
        smooth_window=effective_window,
        polyorder=polyorder,
        signed=signed,
    )
    candidate_curvature = calculate_curvature(
        candidate_curve,
        smooth_window=effective_window,
        polyorder=polyorder,
        signed=signed,
    )

    trim = max(2, effective_window // 2)
    valid = (
        slice(trim, -trim)
        if n_points > 2 * trim + 5
        else slice(None)
    )
    difference = candidate_curvature[valid] - reference_curvature[valid]
    return float(np.sqrt(np.mean(difference**2)))


def curvature_rmse(
    fix,
    move,
    spacing_mm: Sequence[float] = (1.0, 1.0),
    n_points: int = 200,
    smooth_window: int = 21,
    polyorder: int = 3,
    *,
    signed: bool = False,
) -> float:
    """Lower-case alias for :func:`Curvature`."""
    return Curvature(
        fix,
        move,
        spacing_mm=spacing_mm,
        n_points=n_points,
        smooth_window=smooth_window,
        polyorder=polyorder,
        signed=signed,
    )


__all__ = ["Curvature", "calculate_curvature", "curvature_rmse"]
