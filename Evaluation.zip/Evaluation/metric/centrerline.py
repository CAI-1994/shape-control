# -*- coding: utf-8 -*-
"""Centerline extraction and centerline-position RMSE for 2D binary masks.

The filename intentionally follows the requested ``centrerline.py`` spelling.
The public metric itself uses the conventional ``CenterlineRMSE`` name.

Processing performed by this module:

1. convert the input to a 2D boolean mask;
2. keep the largest 8-connected foreground component and fill its holes;
3. skeletonize it to a one-pixel-wide centerline;
4. find the longest geodesic path through the skeleton graph;
5. uniformly resample that ordered path by arc length;
6. compare both possible path directions and retain the lower RMSE.

The metric accepts NumPy arrays and, when PyTorch is installed, tensors.
Non-zero values are foreground. Distances use the unit supplied by
``spacing_mm``; with the default spacing they are in pixels.
"""

from __future__ import annotations

from typing import Sequence

import numpy as np
from scipy import ndimage
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import dijkstra
from skimage.morphology import skeletonize

try:
    import torch
except ImportError:  # pragma: no cover - NumPy inputs do not need PyTorch
    torch = None


class CenterlineError(ValueError):
    """Raised when a valid ordered centerline cannot be extracted."""


def as_2d_binary_mask(mask) -> np.ndarray:
    """Convert a NumPy array or PyTorch tensor to a 2D boolean mask."""
    if torch is not None and torch.is_tensor(mask):
        array = mask.detach().cpu().numpy()
    else:
        array = np.asarray(mask)

    if array.ndim != 2:
        raise ValueError(
            f"Unsupported evaluation dimension {array.ndim}; "
            "pass one 2D mask at a time"
        )
    return np.ascontiguousarray(array.astype(bool, copy=False))


def validate_spacing(spacing_mm: Sequence[float]) -> tuple[float, float]:
    """Validate and normalize ``(row_spacing, column_spacing)``."""
    spacing = np.asarray(spacing_mm, dtype=float)
    if spacing.shape != (2,):
        raise ValueError(
            "spacing_mm must contain row and column spacing, "
            f"received shape {spacing.shape}"
        )
    if not np.all(np.isfinite(spacing)) or np.any(spacing <= 0):
        raise ValueError("spacing_mm values must be finite and positive")
    return float(spacing[0]), float(spacing[1])


def largest_connected_component(mask) -> np.ndarray:
    """Return the largest 8-connected foreground component."""
    binary = as_2d_binary_mask(mask)
    labels, component_count = ndimage.label(
        binary,
        structure=np.ones((3, 3), dtype=bool),
    )
    if component_count == 0:
        return np.zeros_like(binary, dtype=bool)

    component_sizes = np.bincount(labels.ravel())
    component_sizes[0] = 0
    largest_label = int(np.argmax(component_sizes))
    return labels == largest_label


def prepare_centerline_mask(mask) -> np.ndarray:
    """Prepare a segmentation mask for skeleton-based centerline extraction."""
    largest = largest_connected_component(mask)
    if not largest.any():
        return largest
    return np.ascontiguousarray(ndimage.binary_fill_holes(largest), dtype=bool)


def ordered_centerline(
    mask,
    spacing_mm: Sequence[float] = (1.0, 1.0),
) -> np.ndarray:
    """Extract the longest ordered skeleton path in physical ``(x, y)``.

    Branches caused by rasterization are handled by selecting the longest
    endpoint-to-endpoint geodesic path. If no endpoint pair exists (for
    example, a loop), a two-sweep graph-diameter approximation is used.
    """
    row_spacing, column_spacing = validate_spacing(spacing_mm)
    prepared_mask = prepare_centerline_mask(mask)
    skeleton = skeletonize(prepared_mask)
    skeleton = largest_connected_component(skeleton)
    pixels = np.argwhere(skeleton)  # (row, column)

    if len(pixels) < 2:
        raise CenterlineError(
            "The extracted skeleton must contain at least two pixels"
        )

    pixel_to_index = {tuple(pixel): index for index, pixel in enumerate(pixels)}
    graph_rows: list[int] = []
    graph_columns: list[int] = []
    graph_weights: list[float] = []
    neighbour_offsets = (
        (-1, -1),
        (-1, 0),
        (-1, 1),
        (0, -1),
        (0, 1),
        (1, -1),
        (1, 0),
        (1, 1),
    )

    for index, (row, column) in enumerate(pixels):
        for delta_row, delta_column in neighbour_offsets:
            neighbour = pixel_to_index.get(
                (row + delta_row, column + delta_column)
            )
            if neighbour is None or neighbour <= index:
                continue

            distance = float(
                np.hypot(
                    delta_row * row_spacing,
                    delta_column * column_spacing,
                )
            )
            graph_rows.extend((index, neighbour))
            graph_columns.extend((neighbour, index))
            graph_weights.extend((distance, distance))

    graph = csr_matrix(
        (graph_weights, (graph_rows, graph_columns)),
        shape=(len(pixels), len(pixels)),
    )
    degrees = np.diff(graph.indptr)
    endpoints = np.flatnonzero(degrees == 1)

    if len(endpoints) >= 2:
        distances, predecessors = dijkstra(
            graph,
            directed=False,
            indices=endpoints,
            return_predecessors=True,
        )
        endpoint_distances = distances[:, endpoints]
        finite_distances = np.where(
            np.isfinite(endpoint_distances),
            endpoint_distances,
            -np.inf,
        )
        source_row, target_column = np.unravel_index(
            int(np.argmax(finite_distances)),
            finite_distances.shape,
        )
        source = int(endpoints[source_row])
        target = int(endpoints[target_column])
        predecessor_row = predecessors[source_row]
    else:
        first_distances = dijkstra(graph, directed=False, indices=0)
        source = int(
            np.argmax(np.where(np.isfinite(first_distances), first_distances, -np.inf))
        )
        second_distances, predecessor_row = dijkstra(
            graph,
            directed=False,
            indices=source,
            return_predecessors=True,
        )
        target = int(
            np.argmax(
                np.where(np.isfinite(second_distances), second_distances, -np.inf)
            )
        )

    ordered_indices = [target]
    current = target
    while current != source:
        current = int(predecessor_row[current])
        if current < 0:
            raise CenterlineError("Failed to reconstruct the skeleton path")
        ordered_indices.append(current)
    ordered_indices.reverse()

    ordered_pixels = pixels[ordered_indices]
    return np.column_stack(
        (
            ordered_pixels[:, 1] * column_spacing,
            ordered_pixels[:, 0] * row_spacing,
        )
    ).astype(float, copy=False)


def resample_curve(curve, n_points: int = 200) -> np.ndarray:
    """Uniformly resample an ordered ``N x 2`` curve by arc length."""
    points = np.asarray(curve, dtype=float)
    if points.ndim != 2 or points.shape[1] != 2:
        raise ValueError(f"curve must have shape N x 2, received {points.shape}")
    if n_points < 2:
        raise ValueError("n_points must be at least 2")
    if len(points) < 2:
        raise CenterlineError("The centerline must contain at least two points")

    segment_lengths = np.linalg.norm(np.diff(points, axis=0), axis=1)
    keep = np.r_[True, segment_lengths > 1e-12]
    points = points[keep]
    if len(points) < 2:
        raise CenterlineError("The centerline has zero length")

    segment_lengths = np.linalg.norm(np.diff(points, axis=0), axis=1)
    cumulative_length = np.r_[0.0, np.cumsum(segment_lengths)]
    if cumulative_length[-1] <= 0:
        raise CenterlineError("The centerline has zero length")

    target_length = np.linspace(0.0, cumulative_length[-1], int(n_points))
    x = np.interp(target_length, cumulative_length, points[:, 0])
    y = np.interp(target_length, cumulative_length, points[:, 1])
    return np.column_stack((x, y))


def extract_resampled_centerline(
    mask,
    spacing_mm: Sequence[float] = (1.0, 1.0),
    n_points: int = 200,
) -> np.ndarray:
    """Run centerline preprocessing, ordering, and arc-length resampling."""
    return resample_curve(
        ordered_centerline(mask, spacing_mm=spacing_mm),
        n_points=n_points,
    )


def align_curve_direction(
    reference_curve,
    candidate_curve,
) -> tuple[np.ndarray, bool]:
    """Orient a candidate curve to minimize pointwise error to a reference."""
    reference = np.asarray(reference_curve, dtype=float)
    candidate = np.asarray(candidate_curve, dtype=float)
    if reference.shape != candidate.shape:
        raise ValueError(
            "Centerline shapes differ: "
            f"reference -> {reference.shape}, candidate -> {candidate.shape}"
        )

    forward_mse = float(np.mean(np.sum((candidate - reference) ** 2, axis=1)))
    reverse_mse = float(
        np.mean(np.sum((candidate[::-1] - reference) ** 2, axis=1))
    )
    if reverse_mse < forward_mse:
        return candidate[::-1].copy(), True
    return candidate, False


def CenterlineRMSE(
    fix,
    move,
    spacing_mm: Sequence[float] = (1.0, 1.0),
    n_points: int = 200,
) -> float:
    """Calculate pointwise centerline-position RMSE for two 2D masks.

    ``fix`` is the reference mask and ``move`` is the prediction. If either
    mask cannot produce a non-degenerate centerline, ``inf`` is returned so a
    batch evaluation can mark and exclude that invalid distance.
    """
    fix_mask = as_2d_binary_mask(fix)
    move_mask = as_2d_binary_mask(move)
    if fix_mask.shape != move_mask.shape:
        raise ValueError(
            f"Received two masks with different shapes: fix -> {fix_mask.shape}, "
            f"move -> {move_mask.shape}"
        )
    validate_spacing(spacing_mm)

    if not fix_mask.any() or not move_mask.any():
        return float("inf")

    try:
        reference_curve = extract_resampled_centerline(
            fix_mask,
            spacing_mm=spacing_mm,
            n_points=n_points,
        )
        candidate_curve = extract_resampled_centerline(
            move_mask,
            spacing_mm=spacing_mm,
            n_points=n_points,
        )
    except CenterlineError:
        return float("inf")

    candidate_curve, _ = align_curve_direction(reference_curve, candidate_curve)
    squared_distances = np.sum(
        (candidate_curve - reference_curve) ** 2,
        axis=1,
    )
    return float(np.sqrt(np.mean(squared_distances)))


def centerline_rmse(
    fix,
    move,
    spacing_mm: Sequence[float] = (1.0, 1.0),
    n_points: int = 200,
) -> float:
    """Lower-case alias for :func:`CenterlineRMSE`."""
    return CenterlineRMSE(fix, move, spacing_mm=spacing_mm, n_points=n_points)


__all__ = [
    "CenterlineError",
    "CenterlineRMSE",
    "align_curve_direction",
    "as_2d_binary_mask",
    "centerline_rmse",
    "extract_resampled_centerline",
    "largest_connected_component",
    "ordered_centerline",
    "prepare_centerline_mask",
    "resample_curve",
    "validate_spacing",
]
