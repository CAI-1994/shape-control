# -*- coding: utf-8 -*-
"""Preprocess RGB catheter renderings into binary masks.

The dataset uses a pure-white background and several anti-aliased blue shades
for the catheter. Therefore, every pixel that differs from white is treated as
foreground. No resizing or morphology is applied, so the original geometry is
preserved for Dice and HD95.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np
from PIL import Image


class PreprocessError(ValueError):
    """Raised when an image cannot be converted into a valid metric mask."""


@dataclass(frozen=True)
class MaskData:
    """A preprocessed binary mask and its basic quality-control metadata."""

    path: Path
    mask: np.ndarray
    image_shape: tuple[int, int]
    foreground_pixels: int

    @property
    def is_empty(self) -> bool:
        return self.foreground_pixels == 0


def rgb_to_binary_mask(
    image: np.ndarray,
    *,
    background_rgb: Sequence[int] = (255, 255, 255),
    background_tolerance: int = 0,
) -> np.ndarray:
    """Convert an RGB image to a 2D boolean foreground mask.

    A pixel is foreground when at least one RGB channel differs from the
    configured background by more than ``background_tolerance``.

    Args:
        image: ``H x W x 3`` RGB array.
        background_rgb: RGB value used by the image background.
        background_tolerance: Maximum per-channel difference still considered
            background. The inspected dataset is lossless PNG with exact white
            backgrounds, so the default is ``0``.

    Returns:
        A contiguous ``H x W`` boolean array.
    """
    array = np.asarray(image)
    if array.ndim != 3 or array.shape[2] != 3:
        raise PreprocessError(
            f"Expected an HxWx3 RGB image, received shape {array.shape}"
        )
    if not 0 <= background_tolerance <= 255:
        raise PreprocessError(
            "background_tolerance must be an integer between 0 and 255"
        )

    background = np.asarray(background_rgb, dtype=np.int16)
    if background.shape != (3,):
        raise PreprocessError(
            f"background_rgb must contain exactly 3 values, got {background_rgb}"
        )
    if np.any(background < 0) or np.any(background > 255):
        raise PreprocessError("background_rgb values must be between 0 and 255")

    difference = np.abs(array.astype(np.int16) - background)
    mask = np.any(difference > background_tolerance, axis=2)
    return np.ascontiguousarray(mask, dtype=bool)


def load_binary_mask(
    image_path: str | Path,
    *,
    expected_shape: tuple[int, int] | None = None,
    background_rgb: Sequence[int] = (255, 255, 255),
    background_tolerance: int = 0,
) -> MaskData:
    """Load one image and convert it to a metric-ready binary mask."""
    path = Path(image_path)
    if not path.is_file():
        raise PreprocessError(f"Image does not exist: {path}")

    try:
        with Image.open(path) as image:
            rgb = np.asarray(image.convert("RGB"))
    except (OSError, ValueError) as error:
        raise PreprocessError(f"Failed to read image {path}: {error}") from error

    mask = rgb_to_binary_mask(
        rgb,
        background_rgb=background_rgb,
        background_tolerance=background_tolerance,
    )
    image_shape = (int(mask.shape[0]), int(mask.shape[1]))
    if expected_shape is not None and image_shape != expected_shape:
        raise PreprocessError(
            f"Image shape mismatch for {path}: expected {expected_shape}, "
            f"received {image_shape}"
        )

    return MaskData(
        path=path,
        mask=mask,
        image_shape=image_shape,
        foreground_pixels=int(mask.sum()),
    )


def validate_mask_pair(ground_truth: MaskData, prediction: MaskData) -> None:
    """Validate that two preprocessed masks can be compared."""
    if ground_truth.image_shape != prediction.image_shape:
        raise PreprocessError(
            "Ground-truth and prediction shapes differ: "
            f"{ground_truth.path} -> {ground_truth.image_shape}, "
            f"{prediction.path} -> {prediction.image_shape}"
        )


__all__ = [
    "MaskData",
    "PreprocessError",
    "load_binary_mask",
    "rgb_to_binary_mask",
    "validate_mask_pair",
]
