# -*- coding: utf-8 -*-
"""Dice coefficient calculation.

The implementation is based on ``ViTRegist/utils/metrics.py`` and adds support
for 2D masks, which is the shape used by the current PNG data.

Accepted inputs:
    - 2D mask: returns a float.
    - 3D mask: returns a float, following the source implementation.
    - 4D batched mask: returns a list of floats.

Inputs may be PyTorch tensors or NumPy arrays. Non-zero values are treated as
foreground.
"""

import numpy as np

try:
    import torch
except ImportError:  # pragma: no cover - allows NumPy-only use
    torch = None


def _is_torch_tensor(value):
    return torch is not None and torch.is_tensor(value)


def _as_bool_mask(value):
    if _is_torch_tensor(value):
        return value.bool()
    return np.asarray(value).astype(bool, copy=False)


def _dice_single(fix, move):
    if _is_torch_tensor(fix):
        volume_sum = torch.sum(fix) + torch.sum(move)
        if volume_sum.item() == 0:
            return 0.0
        intersection = fix & move
        return float((2 * torch.sum(intersection) / volume_sum).item())

    volume_sum = np.count_nonzero(fix) + np.count_nonzero(move)
    if volume_sum == 0:
        return 0.0
    intersection = np.logical_and(fix, move)
    return float(2 * np.count_nonzero(intersection) / volume_sum)


def Dice(fix, move):
    """Calculate the Dice coefficient.

    This preserves the source function's convention that two empty masks
    return ``0``.
    """
    if fix.shape != move.shape:
        raise ValueError(
            "Received two masks with different shapes: "
            f"fix -> {fix.shape}, move -> {move.shape}"
        )

    fix = _as_bool_mask(fix)
    move = _as_bool_mask(move)

    if fix.ndim == 4:
        return [_dice_single(fix[idx], move[idx]) for idx in range(fix.shape[0])]
    if fix.ndim in (2, 3):
        return _dice_single(fix, move)
    raise ValueError(f"Unsupported evaluation dimension {fix.ndim}")


def dice(fix, move):
    """Lower-case alias for :func:`Dice`."""
    return Dice(fix, move)


__all__ = ["Dice", "dice"]
