# -*- coding: utf-8 -*-
"""Average symmetric surface distance (ASSD) for 2D binary masks."""

from __future__ import annotations

from typing import Sequence

import numpy as np
from scipy import ndimage

from metric.centrerline import as_2d_binary_mask, validate_spacing


def binary_boundary(mask, connectivity: int = 1) -> np.ndarray:
    """Extract the inner one-pixel boundary of a 2D foreground mask."""
    binary = as_2d_binary_mask(mask)
    if connectivity not in (1, 2):
        raise ValueError("connectivity must be 1 (4-neighbour) or 2 (8-neighbour)")
    structure = ndimage.generate_binary_structure(2, connectivity)
    eroded = ndimage.binary_erosion(
        binary,
        structure=structure,
        border_value=0,
    )
    return binary & ~eroded


def ASSD(
    fix,
    move,
    spacing_mm: Sequence[float] = (1.0, 1.0),
    connectivity: int = 1,
) -> float:
    """Calculate pooled average symmetric boundary distance.

    The returned value is

    ``(sum(d(fix_boundary, move_boundary)) +``
    `` sum(d(move_boundary, fix_boundary))) /``
    ``(len(fix_boundary) + len(move_boundary))``.

    Its unit is the same as ``spacing_mm``. If either boundary is empty,
    ``inf`` is returned.
    """
    fix_mask = as_2d_binary_mask(fix)
    move_mask = as_2d_binary_mask(move)
    if fix_mask.shape != move_mask.shape:
        raise ValueError(
            f"Received two masks with different shapes: fix -> {fix_mask.shape}, "
            f"move -> {move_mask.shape}"
        )
    spacing = validate_spacing(spacing_mm)

    fix_boundary = binary_boundary(fix_mask, connectivity=connectivity)
    move_boundary = binary_boundary(move_mask, connectivity=connectivity)
    if not fix_boundary.any() or not move_boundary.any():
        return float("inf")

    distance_to_move = ndimage.distance_transform_edt(
        ~move_boundary,
        sampling=spacing,
    )
    distance_to_fix = ndimage.distance_transform_edt(
        ~fix_boundary,
        sampling=spacing,
    )
    fix_to_move = distance_to_move[fix_boundary]
    move_to_fix = distance_to_fix[move_boundary]

    return float(
        (fix_to_move.sum() + move_to_fix.sum())
        / (fix_to_move.size + move_to_fix.size)
    )


def assd(
    fix,
    move,
    spacing_mm: Sequence[float] = (1.0, 1.0),
    connectivity: int = 1,
) -> float:
    """Lower-case alias for :func:`ASSD`."""
    return ASSD(
        fix,
        move,
        spacing_mm=spacing_mm,
        connectivity=connectivity,
    )


average_symmetric_surface_distance = ASSD


__all__ = [
    "ASSD",
    "assd",
    "average_symmetric_surface_distance",
    "binary_boundary",
]
