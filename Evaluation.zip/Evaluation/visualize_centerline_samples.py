#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Visualize representative extracted centerlines beside ground truth.

By default, this script reads ``metrics_case-level.xlsx`` and selects low,
median, and high centerline-RMSE cases for each camera from ``Mamba_weight``.
Each output image places the method prediction on the left and ground truth on
the right. The overlaid centerlines use exactly the same extraction,
arc-length resampling, and direction matching as the metric calculation.
"""

from __future__ import annotations

import argparse
import csv
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

import numpy as np
from openpyxl import load_workbook
from PIL import Image, ImageDraw, ImageFont

from metric.centrerline import (
    align_curve_direction,
    extract_resampled_centerline,
)


PROJECT_ROOT = Path(__file__).resolve().parent
DEFAULT_DATA_ROOT = PROJECT_ROOT / "data"
DEFAULT_CASE_LEVEL_PATH = PROJECT_ROOT / "metrics_case-level.xlsx"
DEFAULT_SAMPLES_DIR = PROJECT_ROOT / "samples"
DEFAULT_GT_DIR = "test3-ground truth"


@dataclass(frozen=True)
class SelectedCase:
    camera: str
    case_id: int | str
    centerline_rmse: float
    selection: str


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Overlay extracted centerlines on representative prediction/GT pairs."
        )
    )
    parser.add_argument(
        "--method",
        default="Mamba_weight",
        help="Method label or data-directory name (default: Mamba_weight).",
    )
    parser.add_argument(
        "--data-root",
        type=Path,
        default=DEFAULT_DATA_ROOT,
        help=f"Dataset root (default: {DEFAULT_DATA_ROOT}).",
    )
    parser.add_argument(
        "--gt-dir",
        default=DEFAULT_GT_DIR,
        help=f"Ground-truth directory name (default: {DEFAULT_GT_DIR!r}).",
    )
    parser.add_argument(
        "--case-level-xlsx",
        type=Path,
        default=DEFAULT_CASE_LEVEL_PATH,
        help=f"Case-level metric workbook (default: {DEFAULT_CASE_LEVEL_PATH}).",
    )
    parser.add_argument(
        "--samples-dir",
        type=Path,
        default=DEFAULT_SAMPLES_DIR,
        help=f"Visualization output directory (default: {DEFAULT_SAMPLES_DIR}).",
    )
    parser.add_argument(
        "--cases-per-camera",
        type=int,
        default=3,
        help=(
            "Representative RMSE quantiles selected per camera "
            "(default: 3, corresponding to low/median/high)."
        ),
    )
    parser.add_argument(
        "--spacing",
        type=float,
        nargs=2,
        metavar=("ROW_SPACING", "COL_SPACING"),
        default=(1.0, 1.0),
        help="Spacing used by centerline extraction (default: 1.0 1.0).",
    )
    parser.add_argument(
        "--n-points",
        type=int,
        default=200,
        help="Arc-length centerline samples (default: 200).",
    )
    parser.add_argument(
        "--scale",
        type=int,
        default=3,
        help="Integer image enlargement factor (default: 3).",
    )
    return parser.parse_args()


def display_method_name(directory_name: str) -> str:
    for prefix in ("test3_4001-5000_", "test3_"):
        if directory_name.startswith(prefix):
            return directory_name[len(prefix) :]
    return directory_name


def safe_sheet_name(value: str) -> str:
    return (re.sub(r"[\[\]:*?/\\]", "_", value)[:31] or "Sheet")


def resolve_method_directory(data_root: Path, method: str, gt_dir: str) -> Path:
    matches = [
        path
        for path in data_root.iterdir()
        if path.is_dir()
        and path.name != gt_dir
        and (path.name == method or display_method_name(path.name) == method)
    ]
    if len(matches) != 1:
        raise ValueError(
            f"Expected exactly one data directory for method {method!r}, "
            f"found {[path.name for path in matches]}"
        )
    return matches[0]


def _normalized_case_id(value) -> int | str:
    if isinstance(value, float) and value.is_integer():
        return int(value)
    return value


def load_centerline_results(
    workbook_path: Path,
    method_label: str,
) -> dict[str, list[tuple[int | str, float]]]:
    """Read finite case-level centerline RMSE values grouped by camera."""
    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    sheet_name = safe_sheet_name(f"{method_label}_vs_GT")
    if sheet_name not in workbook.sheetnames:
        workbook.close()
        raise ValueError(
            f"Sheet {sheet_name!r} not found in {workbook_path}; "
            f"available sheets: {workbook.sheetnames}"
        )

    worksheet = workbook[sheet_name]
    rows = worksheet.iter_rows(values_only=True)
    headers = next(rows)
    header_to_index = {str(value): index for index, value in enumerate(headers)}
    required = ("Camera", "Case ID", "Centerline RMSE")
    missing = [name for name in required if name not in header_to_index]
    if missing:
        workbook.close()
        raise ValueError(
            f"Missing columns in {workbook_path}/{sheet_name}: {missing}"
        )

    grouped: dict[str, list[tuple[int | str, float]]] = {}
    for row in rows:
        camera = row[header_to_index["Camera"]]
        case_id = row[header_to_index["Case ID"]]
        rmse = row[header_to_index["Centerline RMSE"]]
        if camera is None or case_id is None or rmse is None:
            continue
        rmse = float(rmse)
        if not np.isfinite(rmse):
            continue
        grouped.setdefault(str(camera), []).append(
            (_normalized_case_id(case_id), rmse)
        )
    workbook.close()
    return grouped


def select_representative_cases(
    grouped_results: dict[str, list[tuple[int | str, float]]],
    cases_per_camera: int,
) -> list[SelectedCase]:
    """Select evenly spaced RMSE ranks, including the lowest and highest."""
    if cases_per_camera < 1:
        raise ValueError("cases_per_camera must be at least 1")

    selected: list[SelectedCase] = []
    for camera in sorted(grouped_results):
        ranked = sorted(grouped_results[camera], key=lambda item: item[1])
        if not ranked:
            continue
        count = min(cases_per_camera, len(ranked))
        indices = np.rint(np.linspace(0, len(ranked) - 1, count)).astype(int)

        for position, index in enumerate(indices):
            if count == 1:
                label = "median"
                index = (len(ranked) - 1) // 2
            elif count == 3:
                label = ("low", "median", "high")[position]
            else:
                percentile = int(round(100 * index / max(len(ranked) - 1, 1)))
                label = f"p{percentile:02d}"
            case_id, rmse = ranked[int(index)]
            selected.append(
                SelectedCase(
                    camera=camera,
                    case_id=case_id,
                    centerline_rmse=float(rmse),
                    selection=label,
                )
            )
    return selected


def load_font(size: int) -> ImageFont.ImageFont:
    candidates = (
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
        Path("/usr/share/fonts/truetype/liberation2/LiberationSans-Bold.ttf"),
    )
    for path in candidates:
        if path.is_file():
            return ImageFont.truetype(str(path), size=size)
    return ImageFont.load_default()


def render_panel(
    image_path: Path,
    curve: np.ndarray,
    title: str,
    *,
    scale: int,
    header_height: int,
) -> Image.Image:
    with Image.open(image_path) as source:
        image = source.convert("RGB")
    image = image.resize(
        (image.width * scale, image.height * scale),
        resample=Image.Resampling.NEAREST,
    )

    panel = Image.new(
        "RGB",
        (image.width, image.height + header_height),
        color="white",
    )
    panel.paste(image, (0, header_height))
    draw = ImageDraw.Draw(panel)
    font = load_font(max(15, 7 * scale))
    draw.text(
        (12, max(4, (header_height - font.size) // 2)),
        title,
        fill=(20, 20, 20),
        font=font,
    )

    points = [
        (
            int(round(x * scale)),
            int(round(y * scale)) + header_height,
        )
        for x, y in curve
    ]
    line_width = max(3, 2 * scale)
    draw.line(points, fill=(230, 25, 25), width=line_width, joint="curve")

    endpoint_radius = max(5, 3 * scale)
    for point, color in (
        (points[0], (0, 170, 80)),
        (points[-1], (255, 145, 0)),
    ):
        x, y = point
        draw.ellipse(
            (
                x - endpoint_radius,
                y - endpoint_radius,
                x + endpoint_radius,
                y + endpoint_radius,
            ),
            fill=color,
            outline=(255, 255, 255),
            width=max(1, scale),
        )
    return panel


def render_comparison(
    method_image_path: Path,
    gt_image_path: Path,
    method_curve: np.ndarray,
    gt_curve: np.ndarray,
    *,
    method_label: str,
    selected_case: SelectedCase,
    scale: int,
) -> Image.Image:
    header_height = 18 * scale
    left = render_panel(
        method_image_path,
        method_curve,
        f"{method_label} (prediction)",
        scale=scale,
        header_height=header_height,
    )
    right = render_panel(
        gt_image_path,
        gt_curve,
        "Ground Truth",
        scale=scale,
        header_height=header_height,
    )

    gap = 8 * scale
    footer_height = 34 * scale
    canvas = Image.new(
        "RGB",
        (
            left.width + gap + right.width,
            max(left.height, right.height) + footer_height,
        ),
        color=(242, 244, 247),
    )
    canvas.paste(left, (0, 0))
    canvas.paste(right, (left.width + gap, 0))

    draw = ImageDraw.Draw(canvas)
    font = load_font(max(13, 5 * scale))
    result_text = (
        f"Camera: {selected_case.camera} | Case: {selected_case.case_id} | "
        f"{selected_case.selection} Centerline RMSE: "
        f"{selected_case.centerline_rmse:.4f} pixel"
    )
    legend_text = (
        "Overlay: red = extracted centerline; "
        "green/orange = direction-matched endpoints"
    )
    draw.text(
        (10, left.height + max(3, 3 * scale)),
        result_text,
        fill=(25, 25, 25),
        font=font,
    )
    draw.text(
        (10, left.height + 17 * scale),
        legend_text,
        fill=(25, 25, 25),
        font=font,
    )
    return canvas


def case_filename(case_id: int | str) -> str:
    return f"{case_id}.png"


def safe_filename_part(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("_") or "value"


def write_selection_manifest(
    output_path: Path,
    method_label: str,
    selected_cases: Sequence[SelectedCase],
) -> None:
    with output_path.open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(
            ["method", "camera", "case_id", "selection", "centerline_rmse"]
        )
        for selected in selected_cases:
            writer.writerow(
                [
                    method_label,
                    selected.camera,
                    selected.case_id,
                    selected.selection,
                    selected.centerline_rmse,
                ]
            )


def main() -> None:
    args = parse_args()
    if args.scale < 1:
        raise ValueError("--scale must be at least 1")
    if args.n_points < 2:
        raise ValueError("--n-points must be at least 2")
    if any(value <= 0 for value in args.spacing):
        raise ValueError("--spacing values must be positive")

    data_root = args.data_root.resolve()
    method_directory = resolve_method_directory(
        data_root,
        args.method,
        args.gt_dir,
    )
    method_label = display_method_name(method_directory.name)
    gt_directory = data_root / args.gt_dir
    if not gt_directory.is_dir():
        raise FileNotFoundError(f"Ground-truth directory not found: {gt_directory}")

    grouped = load_centerline_results(args.case_level_xlsx, method_label)
    selected_cases = select_representative_cases(
        grouped,
        args.cases_per_camera,
    )
    if not selected_cases:
        raise RuntimeError("No finite centerline-RMSE cases were available")

    output_directory = args.samples_dir.resolve()
    output_directory.mkdir(parents=True, exist_ok=True)
    spacing = (float(args.spacing[0]), float(args.spacing[1]))

    for selected in selected_cases:
        filename = case_filename(selected.case_id)
        method_path = method_directory / selected.camera / filename
        gt_path = gt_directory / selected.camera / filename
        if not method_path.is_file() or not gt_path.is_file():
            raise FileNotFoundError(
                f"Missing selected image pair: {method_path}, {gt_path}"
            )

        with Image.open(method_path) as image:
            method_rgb = np.asarray(image.convert("RGB"))
        with Image.open(gt_path) as image:
            gt_rgb = np.asarray(image.convert("RGB"))
        method_mask = np.any(method_rgb != 255, axis=2)
        gt_mask = np.any(gt_rgb != 255, axis=2)

        gt_curve = extract_resampled_centerline(
            gt_mask,
            spacing_mm=spacing,
            n_points=args.n_points,
        )
        method_curve = extract_resampled_centerline(
            method_mask,
            spacing_mm=spacing,
            n_points=args.n_points,
        )
        method_curve, _ = align_curve_direction(gt_curve, method_curve)
        coordinate_spacing = np.asarray(
            (spacing[1], spacing[0]),
            dtype=float,
        )
        gt_curve_pixels = gt_curve / coordinate_spacing
        method_curve_pixels = method_curve / coordinate_spacing

        comparison = render_comparison(
            method_path,
            gt_path,
            method_curve_pixels,
            gt_curve_pixels,
            method_label=method_label,
            selected_case=selected,
            scale=args.scale,
        )
        output_name = "_".join(
            (
                safe_filename_part(method_label),
                safe_filename_part(selected.camera),
                f"case-{selected.case_id}",
                selected.selection,
            )
        ) + ".png"
        output_path = output_directory / output_name
        comparison.save(output_path)
        print(f"[sample] {output_path}", flush=True)

    manifest_path = output_directory / "selected_cases.csv"
    write_selection_manifest(manifest_path, method_label, selected_cases)
    print(f"[manifest] {manifest_path}", flush=True)


if __name__ == "__main__":
    main()
