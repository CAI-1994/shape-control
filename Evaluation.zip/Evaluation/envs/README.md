# uv 环境配置

当前项目环境信息：

- Python：3.10.20
- uv：0.11.19
- 虚拟环境路径：`envs/metrics`
- 锁定依赖：`envs/requirements.txt`

压缩包仅保留 `envs/metrics` 中的环境元数据，不包含已安装的二进制文件和第三方包。

在项目根目录中运行以下命令即可重建环境：

```bash
uv venv envs/metrics --python 3.10
uv pip install --python envs/metrics/bin/python -r envs/requirements.txt
```
