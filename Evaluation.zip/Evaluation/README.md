# 二维导管形状评价指标与实验结果

本项目将每个方法生成的二维导管图像与 Ground Truth（GT）按“相同相机视角、相同 PNG 文件名”一一配对，并计算 Dice、HD95、中心线位置 RMSE、绝对曲率 RMSE 和平均对称边界距离（ASSD）。

计算结果保存在：

- `metrics_case-level.xlsx`：逐样本结果。每个方法包含两个相机视角，每个视角 1000 个样本，共 2000 行；
- `metrics_results.xlsx`：按相机视角以及全部样本（Overall）汇总的有效样本数、均值和总体标准差。

## 1. 指标定义与计算方法

### 1.1 图像配对与符号

记：

- \(G\)：Ground Truth 二值掩膜；
- \(P\)：某个方法的预测二值掩膜；
- \(r,c\)：像素的行、列坐标；
- \(\partial G,\partial P\)：GT 与预测掩膜的二维边界；
- \(N\)：中心线弧长重采样点数，本次计算中 \(N=200\)。

GT 与预测必须具有完全相同的图像尺寸和坐标系。项目按相同 camera 文件夹和相同 PNG 文件名配对，不进行跨视角比较。

### 1.2 二值化阈值与像素间距

所有 PNG 首先转换为 RGB 图像。当前数据使用纯白背景，因此没有使用 Otsu 阈值。设 RGB 图像为 \(I\)，背景颜色为

\[
\mathbf{b}=(255,255,255),
\]

背景容差为

\[
\tau=0.
\]

二值掩膜定义为：

\[
M_I(r,c)=
\begin{cases}
1, & \displaystyle \max_{k\in\{R,G,B\}}
\left|I_k(r,c)-255\right|>\tau,\\[4pt]
0, & \text{其他情况}.
\end{cases}
\]

因此，只要一个像素的任意 RGB 通道不等于 255，该像素就被视为前景；纯白像素为背景。抗锯齿产生的浅蓝色像素同样会进入前景。

Dice、HD95 和 ASSD 直接使用该二值掩膜，不进行缩放、闭运算或其他形态学修改。中心线相关指标会额外执行最大连通域保留和孔洞填充，具体规则见 1.5。

本次批量计算使用：

\[
\text{spacing}=(s_r,s_c)=(1,1),
\]

其中 \(s_r\) 和 \(s_c\) 分别是行、列方向的像素间距。因此两点之间的距离为：

\[
d_s(a,b)=
\sqrt{\left[(a_r-b_r)s_r\right]^2+
      \left[(a_c-b_c)s_c\right]^2}.
\]

在 \(\text{spacing}=(1,1)\) 时：

- HD95、中心线位置 RMSE 和 ASSD 的单位为 pixel；
- 绝对曲率及其 RMSE 的单位为 \(\mathrm{pixel}^{-1}\)；
- 水平或垂直相邻像素距离为 \(1\) pixel，对角相邻像素距离为 \(\sqrt{2}\) pixel。

### 1.3 Dice 系数

Dice 衡量预测区域与 GT 区域的重叠程度：

\[
\mathrm{Dice}(G,P)=
\frac{2|G\cap P|}{|G|+|P|}.
\]

Dice 的取值通常位于 \([0,1]\)，越大越好。当两个掩膜均为空时，当前代码约定 Dice 为 \(0\)。

### 1.4 95% Hausdorff 距离（HD95）

首先定义点 \(x\) 到集合 \(S\) 的最近距离：

\[
d(x,S)=\min_{y\in S}d_s(x,y).
\]

HD95 使用二维轮廓之间的双向表面距离。当前实现通过 \(2\times2\) 邻域编码提取轮廓元素，并根据像素间距为每个轮廓元素计算对应的轮廓长度权重。

对于一组已按距离从小到大排序的距离 \(d_1,\ldots,d_m\) 及其轮廓长度权重 \(w_1,\ldots,w_m\)，加权 95% 分位数定义为：

\[
Q_{0.95}^{w}
=
\min\left\{
d_k:
\frac{\sum_{i=1}^{k}w_i}
     {\sum_{i=1}^{m}w_i}
\ge 0.95
\right\}.
\]

最终：

\[
\mathrm{HD95}(G,P)
=
\max\left(
Q_{0.95}^{w}\{d(g,\partial P):g\in\partial G\},
Q_{0.95}^{w}\{d(p,\partial G):p\in\partial P\}
\right).
\]

HD95 越小越好。在当前 \(\text{spacing}=(1,1)\) 设置下，单位为 pixel。

### 1.5 中心线提取规则与中心线位置 RMSE

中心线指标不是直接对无序骨架像素做逐点相减，而是对每个二值掩膜依次执行以下处理：

1. 将输入转换为二维布尔掩膜，所有非零值均视为前景；
2. 使用 8 邻域连通性，只保留面积最大的前景连通区域；
3. 对最大连通区域执行孔洞填充；
4. 使用 `skimage.morphology.skeletonize` 将区域细化为单像素骨架；
5. 再次保留最大的 8 邻域骨架连通区域；
6. 将每个骨架像素作为图节点，并连接其 8 邻域骨架像素。边权为

   \[
   w(\Delta r,\Delta c)
   =
   \sqrt{(\Delta r\,s_r)^2+(\Delta c\,s_c)^2};
   \]

7. 将图中度数为 1 的节点作为端点，利用 Dijkstra 最短路径距离寻找距离最远的端点对，并重建两端点之间的最长有序路径；
8. 如果骨架没有至少两个端点，例如出现闭环，则使用两次图搜索近似求取图直径；
9. 将有序骨架坐标由 \((r,c)\) 转换为物理坐标

   \[
   (x,y)=(c\,s_c,r\,s_r);
   \]

10. 分别按照各自中心线的累计弧长，将 GT 和预测中心线均匀重采样为 \(N=200\) 个点。第 \(i\) 个点对应相同的归一化弧长位置；
11. 骨架路径可能从任意端点开始，因此分别计算预测中心线正序和反序与 GT 的误差，选择误差更小的方向作为最终对应关系。

设重采样后的 GT 中心线为

\[
\mathbf{g}_i=(x_i^G,y_i^G),
\]

方向匹配后的预测中心线为

\[
\mathbf{p}_i=(x_i^P,y_i^P),
\qquad i=1,\ldots,N.
\]

中心线位置 RMSE 定义为：

\[
\mathrm{Centerline\ RMSE}
=
\sqrt{
\frac{1}{N}
\sum_{i=1}^{N}
\left\|\mathbf{p}_i-\mathbf{g}_i\right\|_2^2
}.
\]

该指标越小越好。在当前设置下单位为 pixel。

### 1.6 绝对曲率与绝对曲率 RMSE

曲率计算复用 1.5 中提取、排序、弧长重采样和方向匹配后的中心线。为了降低像素化骨架对一阶、二阶导数的影响，首先分别对 \(x\) 和 \(y\) 坐标应用 Savitzky–Golay 平滑：

- 重采样点数：\(N=200\)；
- 平滑窗口：\(W=21\)；
- 多项式阶数：3。

令平滑后的二维中心线为

\[
\mathbf{c}(t)=(x(t),y(t)),\qquad t\in[0,1].
\]

绝对曲率定义为：

\[
\kappa(t)
=
\frac{
\left|x'(t)y''(t)-y'(t)x''(t)\right|
}{
\left(x'(t)^2+y'(t)^2\right)^{3/2}
}.
\]

这里比较的是绝对曲率，即弯曲程度，不保留顺时针或逆时针弯曲的正负号。

中心线端点处的二阶导数最不稳定，因此当前实现从两端各排除

\[
T=\max\left(2,\left\lfloor\frac{W}{2}\right\rfloor\right)=10
\]

个采样点。本次实际参与曲率比较的点数为：

\[
N_{\mathrm{valid}}=N-2T=180.
\]

设有效位置上的 GT 和预测绝对曲率分别为
\(\kappa_i^G\) 和 \(\kappa_i^P\)，则：

\[
\mathrm{Curvature\ RMSE}
=
\sqrt{
\frac{1}{N_{\mathrm{valid}}}
\sum_{i=1}^{N_{\mathrm{valid}}}
\left(\kappa_i^P-\kappa_i^G\right)^2
}.
\]

绝对曲率 RMSE 越小越好。在当前设置下单位为 \(\mathrm{pixel}^{-1}\)。

### 1.7 平均对称边界距离（ASSD）

ASSD 比较的是两个完整形状的二维边界。在本项目中，边界通过一次二值腐蚀获得：

\[
\partial M=M\cap\neg\mathrm{Erode}(M),
\]

其中腐蚀使用 4 邻域结构。对每一个边界像素，使用欧氏距离变换寻找另一条边界上的最近像素。

ASSD 定义为：

\[
\mathrm{ASSD}(G,P)
=
\frac{
\displaystyle
\sum_{g\in\partial G}d(g,\partial P)
+
\sum_{p\in\partial P}d(p,\partial G)
}{
|\partial G|+|\partial P|
}.
\]

该实现将两个方向上的所有边界距离合并后求平均，即分母为两条边界的像素总数；不是先分别求两个方向的均值再简单除以 2。

ASSD 越小越好。在当前 \(\text{spacing}=(1,1)\) 设置下单位为 pixel。

### 1.8 无效样本与汇总规则

如果 HD95、中心线位置 RMSE、绝对曲率 RMSE 或 ASSD 因空掩膜、空边界或退化中心线而无法计算，对应函数返回无穷大；写入逐样本工作簿时转换为空值，并在汇总均值和标准差时排除。当前结果中所有方法、所有视角的五项指标均为有效值。

对于一个 scope 内的 \(n\) 个有限结果 \(m_1,\ldots,m_n\)，`metrics_results.xlsx` 使用算术均值：

\[
\bar m=\frac{1}{n}\sum_{i=1}^{n}m_i,
\]

以及总体标准差（population standard deviation，`ddof=0`）：

\[
\sigma=
\sqrt{
\frac{1}{n}
\sum_{i=1}^{n}(m_i-\bar m)^2
}.
\]

两个单独 camera 的 \(n=1000\)，Overall 将两个 camera 的全部结果合并后重新统计，\(n=2000\)。Overall 的标准差不是两个 camera 标准差的简单平均。

## 2. 不同方法的指标结果

以下结果来自 `metrics_results.xlsx`，统一表示为“均值 ± 总体标准差”，并保留三位小数。

- 表头中的 ↑ 表示越大越好，↓ 表示越小越好；
- <span style="color:red"><strong>红色粗体</strong></span>表示该列最佳结果；
- <span style="color:blue"><strong>蓝色粗体</strong></span>表示该列次佳结果；
- 最佳和次佳排名根据未四舍五入的均值确定，标准差不参与排名。

### 2.1 Camera：LAO_RAO_0_CAU_CRA_0

每种方法包含 1000 个有效样本。

| 方法 | Dice ↑ | HD95 ↓ (pixel) | 中心线位置 RMSE ↓ (pixel) | 绝对曲率 RMSE ↓ (pixel⁻¹) | ASSD ↓ (pixel) |
|---|---:|---:|---:|---:|---:|
| CNN | 0.413 ± 0.248 | 30.053 ± 20.029 | <span style="color:blue"><strong>22.286 ± 15.247</strong></span> | <span style="color:red"><strong>0.122 ± 0.047</strong></span> | 10.252 ± 8.280 |
| Mamba | <span style="color:blue"><strong>0.418 ± 0.256</strong></span> | <span style="color:blue"><strong>29.952 ± 19.907</strong></span> | <span style="color:red"><strong>22.223 ± 14.981</strong></span> | 0.128 ± 0.050 | <span style="color:red"><strong>10.151 ± 8.136</strong></span> |
| Mamba_weight | <span style="color:red"><strong>0.421 ± 0.253</strong></span> | <span style="color:red"><strong>29.852 ± 19.792</strong></span> | 22.294 ± 15.115 | <span style="color:blue"><strong>0.125 ± 0.049</strong></span> | <span style="color:blue"><strong>10.181 ± 8.272</strong></span> |

### 2.2 Camera：LAO_RAO_45_CAU_CRA_30

每种方法包含 1000 个有效样本。

| 方法 | Dice ↑ | HD95 ↓ (pixel) | 中心线位置 RMSE ↓ (pixel) | 绝对曲率 RMSE ↓ (pixel⁻¹) | ASSD ↓ (pixel) |
|---|---:|---:|---:|---:|---:|
| CNN | 0.324 ± 0.172 | 33.080 ± 18.178 | 25.162 ± 14.291 | <span style="color:red"><strong>0.125 ± 0.081</strong></span> | 11.820 ± 7.594 |
| Mamba | <span style="color:red"><strong>0.330 ± 0.176</strong></span> | <span style="color:red"><strong>32.079 ± 18.109</strong></span> | <span style="color:red"><strong>24.501 ± 14.297</strong></span> | 0.129 ± 0.078 | <span style="color:red"><strong>11.458 ± 7.568</strong></span> |
| Mamba_weight | <span style="color:blue"><strong>0.325 ± 0.169</strong></span> | <span style="color:blue"><strong>32.265 ± 17.768</strong></span> | <span style="color:blue"><strong>24.694 ± 14.116</strong></span> | <span style="color:blue"><strong>0.128 ± 0.078</strong></span> | <span style="color:blue"><strong>11.463 ± 7.511</strong></span> |

### 2.3 两个 Camera 合并结果（Overall）

Overall 将两个 camera 的全部样本合并后统计，每种方法包含 2000 个有效样本。

| 方法 | Dice ↑ | HD95 ↓ (pixel) | 中心线位置 RMSE ↓ (pixel) | 绝对曲率 RMSE ↓ (pixel⁻¹) | ASSD ↓ (pixel) |
|---|---:|---:|---:|---:|---:|
| CNN | 0.369 ± 0.218 | 31.567 ± 19.186 | 23.724 ± 14.847 | <span style="color:red"><strong>0.124 ± 0.066</strong></span> | 11.036 ± 7.983 |
| Mamba | <span style="color:red"><strong>0.374 ± 0.224</strong></span> | <span style="color:red"><strong>31.016 ± 19.059</strong></span> | <span style="color:red"><strong>23.362 ± 14.687</strong></span> | 0.128 ± 0.065 | <span style="color:red"><strong>10.804 ± 7.884</strong></span> |
| Mamba_weight | <span style="color:blue"><strong>0.373 ± 0.220</strong></span> | <span style="color:blue"><strong>31.059 ± 18.846</strong></span> | <span style="color:blue"><strong>23.494 ± 14.674</strong></span> | <span style="color:blue"><strong>0.127 ± 0.065</strong></span> | <span style="color:blue"><strong>10.822 ± 7.927</strong></span> |

## 附录 A：中心线提取可视化样例

以下样例来自 `samples/`，展示 `Mamba_weight` 预测结果与 GT 的中心线提取效果。每个 camera 分别按照逐样本中心线位置 RMSE 排序，选取低误差、中位误差和高误差三个代表 case。

每张图中：

- 左侧为 `Mamba_weight` 预测图像，右侧为 GT；
- 红色曲线为经过“骨架化—最长路径排序—弧长重采样”后得到的中心线；
- 绿色和橙色圆点为完成方向匹配后的两个对应端点；
- 图下方给出对应的 camera、case 编号和中心线位置 RMSE；
- 点击缩略图可以查看完整尺寸图像。

### A.1 Camera：LAO_RAO_0_CAU_CRA_0

<table>
  <tr>
    <th>低误差：Case 877<br>RMSE = 0.783 pixel</th>
    <th>中位误差：Case 529<br>RMSE = 22.846 pixel</th>
    <th>高误差：Case 650<br>RMSE = 57.684 pixel</th>
  </tr>
  <tr>
    <td>
      <a href="samples/Mamba_weight_LAO_RAO_0_CAU_CRA_0_case-877_low.png">
        <img src="samples/Mamba_weight_LAO_RAO_0_CAU_CRA_0_case-877_low.png" alt="Camera LAO_RAO_0_CAU_CRA_0 Case 877 低误差中心线样例" width="400">
      </a>
    </td>
    <td>
      <a href="samples/Mamba_weight_LAO_RAO_0_CAU_CRA_0_case-529_median.png">
        <img src="samples/Mamba_weight_LAO_RAO_0_CAU_CRA_0_case-529_median.png" alt="Camera LAO_RAO_0_CAU_CRA_0 Case 529 中位误差中心线样例" width="400">
      </a>
    </td>
    <td>
      <a href="samples/Mamba_weight_LAO_RAO_0_CAU_CRA_0_case-650_high.png">
        <img src="samples/Mamba_weight_LAO_RAO_0_CAU_CRA_0_case-650_high.png" alt="Camera LAO_RAO_0_CAU_CRA_0 Case 650 高误差中心线样例" width="400">
      </a>
    </td>
  </tr>
</table>

### A.2 Camera：LAO_RAO_45_CAU_CRA_30

<table>
  <tr>
    <th>低误差：Case 298<br>RMSE = 0.602 pixel</th>
    <th>中位误差：Case 432<br>RMSE = 24.463 pixel</th>
    <th>高误差：Case 33<br>RMSE = 59.032 pixel</th>
  </tr>
  <tr>
    <td>
      <a href="samples/Mamba_weight_LAO_RAO_45_CAU_CRA_30_case-298_low.png">
        <img src="samples/Mamba_weight_LAO_RAO_45_CAU_CRA_30_case-298_low.png" alt="Camera LAO_RAO_45_CAU_CRA_30 Case 298 低误差中心线样例" width="400">
      </a>
    </td>
    <td>
      <a href="samples/Mamba_weight_LAO_RAO_45_CAU_CRA_30_case-432_median.png">
        <img src="samples/Mamba_weight_LAO_RAO_45_CAU_CRA_30_case-432_median.png" alt="Camera LAO_RAO_45_CAU_CRA_30 Case 432 中位误差中心线样例" width="400">
      </a>
    </td>
    <td>
      <a href="samples/Mamba_weight_LAO_RAO_45_CAU_CRA_30_case-33_high.png">
        <img src="samples/Mamba_weight_LAO_RAO_45_CAU_CRA_30_case-33_high.png" alt="Camera LAO_RAO_45_CAU_CRA_30 Case 33 高误差中心线样例" width="400">
      </a>
    </td>
  </tr>
</table>
